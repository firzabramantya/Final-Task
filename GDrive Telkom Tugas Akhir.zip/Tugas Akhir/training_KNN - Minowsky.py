import pandas as pd
import numpy as np

from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import classification_report
#from sklearn.externals import joblib
from sklearn.metrics import confusion_matrix
from sklearn.model_selection import train_test_split

# load data training
df = pd.read_csv('Ekstraksi.csv')
df

df.head()

# define label
columns = ['min', 'max', 'mean', 'median', 'std']
label = 'type'
data, label = df[columns], df[label]

# split into train and test set
data_training, data_testing, label_training, label_testing = train_test_split(data, label,
                                                                              test_size=0.4)

# training process
# i=1
# while (i<11):
classifier = KNeighborsClassifier(weights='distance',metric='minowsky', n_neighbors = 1)
classifier.fit(data_training, label_training)

# testing process
label_predicted = classifier.predict(data_testing)

# report testing (precision, recall, f1-score, support)
print(classification_report(label_testing, label_predicted))
print(label_testing)
print(label_predicted)

# report testing confusion matrix
cm = confusion_matrix(label_testing, label_predicted)
# print(cm)
# report testing accuracy, sensitivity, specificity
TN = cm[1][1] * 1.0
FN = cm[1][0] * 1.0
TP = cm[0][0] * 1.0
FP = cm[0][1] * 1.0

total = TN + FN + TP + FP

acc = (TP+TN) / (total) * 100
sens = TN / (TN+FP) * 100
spec = TP / (TP+FN) * 100

print('--------------------------------------------')
print('Accuracy : '+ str(acc))
print('Sensitivity : '+ str(sens))
print('Specificity : '+ str(spec))
print('--------------------------------------------')
     #i+=1
# save model
#joblib.dump(classifier, 'model/KNN_classifier.pkl')
print('model saved')
