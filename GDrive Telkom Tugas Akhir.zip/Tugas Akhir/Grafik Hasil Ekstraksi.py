import numpy as np # Numpy - Numerical Python
import matplotlib.pyplot as plt

file = 'Ekstraksi.csv'
a = np.genfromtxt(file, delimiter=',')
t = a[:, 0]
y = a[:, 1]

plt.plot(t / np.pi, y, 'p')  # -> Plot garis
plt.title('Grafik Hasil Ekstraksi')
plt.xlabel('t(sekon)/$\pi$')  # Sumbu -X
# $\pi$ --> untuk memasukan bahasa latex --simbol pi
plt.ylabel('Sumbu y(m)')  # Sumbu -Y
plt.show()