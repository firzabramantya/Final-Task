import numpy as np  # Numpy - Numerical Python
import matplotlib.pyplot as plt

file = 'Ekstraksi.csv'
a = np.genfromtxt(file, delimiter=',')
t = a[:, 0]
y = a[:, 1]

plt.plot(t / np.pi, y, 'p')  # -> Plot garis
plt.title('Grafik Ekstraksi')
plt.xlabel('Waktu')  # Sumbu -X t(sekon)/$\pi$
# $\pi$ --> untuk memasukan bahasa latex --simbol pi
plt.ylabel('Data')  # Sumbu -Y Sumbu y(m)
plt.show()