import pywt
import numpy as np
import csv, io
import Createdataset as c
import soft
import bwr
from sklearn.decomposition import PCA
for j in range(10):
    index = 'sample' + str(j+1) + '.csv'
    with open (index) as csv_file:
        sreader = list(csv.reader(csv_file,delimiter=','))
        header = sreader[0]
        data = sreader[2:len(sreader)]
        ecg1 = []
        for i in range(len(data)):
            ecg1.append(data[i][1])
        # print(ecg1)
        sinyal = soft.waveletSmooth(ecg1)
        (baseline, ecg_out) = bwr.bwr(sinyal)
        nlevelmax = pywt.dwt_max_level(len(ecg_out), 'db6')
        print(nlevelmax)
        coeff = pywt.wavedec(ecg_out, 'db6', level=5)
        ca, cd1, cd2, cd3, cd4, cd5 = coeff
        #(ca, cd) = pywt.dwt(ecg_out, 'haar')
        # ca = ca.reshape(-1, 1)
        # pca = PCA()
        # pca.fit(ca)
        # pca_data = pca.transform(ca)
        # pca_data = pca_data.flatten()
        (min, max, mean, med, std) = c.Createdataset(ca)
        hasil = [min, max, mean, med, std,"SVT"]
        print (hasil)
        with open('Ekstraksi.csv', 'a') as writeFile:
            writer = csv.writer(writeFile)
            writer.writerow(hasil)



