import pywt
import numpy as np
import csv, io
import Createdataset as c
import soft
import bwr
import seaborn
#from sklearn.decomposition import PCA
with open('sample1.csv') as csv_file:
    sreader = list(csv.reader(csv_file,delimiter=','))
    header = sreader[0]
    data = sreader[2:len(sreader)]

    ecg1 = []
    ecg2 = []

    for i in range(len(data)):
        ecg1.append(data[i][1])

    # print(ecg1)
    sinyal = soft.waveletSmooth(ecg1)
    (baseline, ecg_out) = bwr.bwr(sinyal)
    (ca, cd) = pywt.dwt(ecg1, 'haar')
    # print(ca)
    # ca = ca.reshape(-1,1)
    # pca = PCA()
    # pca.fit(ca)
    # pca_data = pca.transform(ca)
    # pca_data=pca_data.flatten()
    (min, max, mean, med, std) = c.Createdataset(ca)
    hasil = ['min','max','mean','median','std','type']
    print (hasil)
    with open('Ekstraksi.csv', 'w') as writeFile:
        writer = csv.writer(writeFile)
        writer.writerow(hasil)

    # (ca, cd) = pywt.dwt(ecg2, 'haar')
    # with open('ektraksi_fitur_ecg2.csv', 'w') as writeFile:
    #     writer = csv.writer(writeFile)
    #     writer.writerows(map(lambda x: [x], ca))

