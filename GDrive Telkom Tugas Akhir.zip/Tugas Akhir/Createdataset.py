import statistics
def Createdataset(fileEKG):
    min = fileEKG.min()
    max = fileEKG.max()
    mean = statistics.mean(fileEKG)
    med = statistics.median(fileEKG)
    std = statistics.stdev(fileEKG)
    return (min,max,mean,med,std)